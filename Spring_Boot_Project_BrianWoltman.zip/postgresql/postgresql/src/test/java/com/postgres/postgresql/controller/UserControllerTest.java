package com.postgres.postgresql.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.List;

import org.junit.jupiter.api.Test;

public class UserControllerTest {
    @Test
    void testgetAllUser() {
        // create an instance of controller, then call GetAllUser function
        // assert equals and make sure list of users is returned

    }
}
