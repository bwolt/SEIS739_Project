const gradeOneContent = `
[
   {
        "id": "1",
        "text": "Elephant",
        "filename": "Elephant.jpg"
    },
   {
        "id": "2",
        "text": "Bald Eagle",
        "filename": "BaldEagle.jpg"    
   },
   {
        "id": "3",
        "text": "Polar Bear",
        "filename": "PolarBear.jpg"   
   },
   {
        "id": "4",
        "text": "Giraffe",
        "filename": "Giraffe.jpg"
   },
   {
        "id": "5",
        "text": "Rabbit",
        "filename": "Rabbit.jpg"
   },
   {
        "id": "6",
        "text": "Turtle",
        "filename": "Turtle.jpg"
   }
]`;

const gradeTwoContent = `
[
     {
          "id": "1",
          "text": "Broccoli",
          "filename": "Broccoli.jpg"
     },
     {
          "id": "2",
          "text": "Cauliflower",
          "filename": "Cauliflower.jpg"
     },
     {
          "id": "3",
          "text": "Spaghetti",
          "filename": "Spaghetti.jpg"
     },
     {
          "id": "4",
          "text": "Watermelon",
          "filename": "Watermelon.jpg"
     },
     {
          "id": "5",
          "text": "Grapes",
          "filename": "Grapes.jpg"
     },
     {
          "id": "6",
          "text": "Orange",
          "filename": "Orange.jpg"
     }
]`;