

//function takes the text and removes a random letter and saves the letter as a variable
//then when user presses a key, it is compared to the variable
//could have this function return the missing letter, and the calling function is what checks for correctness
function getPuzzle(){
    var puzzleBank = [];
    let data = JSON.parse(gradeOneContent);
    puzzleBank = data;
    console.log(puzzleBank);

    //generate random number, and the puzzle of that id will be selected
    //for now, random number 1 to 6.  ao puzzleID from 1 to 6
    let puzzleID = (Math.floor(Math.random()*6)) + 1;
    //document.write(puzzleID + "   ");
    //console.log(puzzleID);

    for (puzzle of puzzleBank){
        if (puzzle.id == puzzleID){    //this will only be true for one puzzle out of whole bank

            document.write('<img src="images/' + puzzle.filename + ' " width = "300" height = "300">');

            const clueText = document.getElementById("clue");
            clueText.style.color = "red";
            //now need to randomly remove one letter and replace it with underscore
            finalText = removeLetter(puzzle.text);
            console.log(puzzle.text);
            clueText.innerText = finalText;

        } else {
            //document.write("Not a match")
        }
    }
}

function removeLetter(puzzletext) {
    console.log(puzzletext);
    length = puzzletext.length;
    console.log(length)
    //generate random number from 0 to (length - 1) then check if that is a space.  If not, remove.  If space, add
    //one to random number and then remove that index from string.  This function should return the index of the removed letter.
    let indexRemoved = (Math.floor(Math.random()*length));
    console.log(indexRemoved);
    if (puzzletext[indexRemoved] == " ")
        indexRemoved = indexRemoved + 1;

    answer = puzzletext[indexRemoved];
    
    finalPuzzle = puzzletext.substring(0, indexRemoved) + "_" + puzzletext.substring(indexRemoved + 1);

    console.log(finalPuzzle)

    return finalPuzzle
    
}

//right after puzzle is generated and presented, this function will be entered, so it needs to sit and wait for a keystroke
function processAnswer(event) {
    let key = event.key;
    let answerText = document.getElementById("answer");
    console.log(key);
    if (key == answer)
        answerText.innerText = "Correct!!  Refresh page for new puzzle"
    else
        answerText.innerText = "Try again!"
}