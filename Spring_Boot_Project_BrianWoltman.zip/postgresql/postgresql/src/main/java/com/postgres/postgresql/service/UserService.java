package com.postgres.postgresql.service;

import java.util.List;

import com.postgres.postgresql.entity.UserEntity;

//this interface contains five methods that realize the crud operations
public interface UserService {

    List<UserEntity> getAllUser();

    UserEntity getUserById(Long userId);

    void saveUser(UserEntity user);

    void updateUser(UserEntity user, Long userid);

    void deleteUseryId(Long userId);

}
