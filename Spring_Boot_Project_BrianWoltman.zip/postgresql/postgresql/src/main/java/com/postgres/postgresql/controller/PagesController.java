package com.postgres.postgresql.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PagesController {

    @RequestMapping("/puzzle")
    public String puzzle() {
        return "puzzle";
    }
}
