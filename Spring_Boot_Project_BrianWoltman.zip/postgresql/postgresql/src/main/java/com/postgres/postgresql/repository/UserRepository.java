package com.postgres.postgresql.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.postgres.postgresql.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Long> { // Long is data type of primary key of user
                                                                          // table

}
