package com.postgres.postgresql.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "user", schema = "public") // 'user' is the name of my table in postgresql database
public class UserEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) // GeneratedValue annotation is for primary key of postgresql table
    private Long id;

    @Column
    private String first;

    @Column
    private String last;

    @Column
    private Long grade;

    // define constructor for UserEntity class. creates a new user to add to
    // database
    public UserEntity(Long id, String first, String last, Long grade) {
        this.id = id;
        this.first = first;
        this.last = last;
        this.grade = grade;
    }

    public UserEntity() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getfirst() {
        return first;
    }

    public void setfirst(String first) {
        this.first = first;
    }

    public String getlast() {
        return last;
    }

    public void setlast(String last) {
        this.last = last;
    }

    // The variable grade is what the front end needs in order to determine which
    // bank array in puzzle-data.js to use
    public Long getgrade() {
        return grade;
    }

    public void setgrade(Long grade) {
        this.grade = grade;
    }

}
