package com.postgres.postgresql.service.implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.postgres.postgresql.entity.UserEntity;
import com.postgres.postgresql.repository.UserRepository;
import com.postgres.postgresql.service.UserService;

@Service
public class UserServiceimpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override // the override annotation indicates the child class method is over-writing its
              // base class method
    public List<UserEntity> getAllUser() {
        return userRepository.findAll();
    }

    @Override
    public UserEntity getUserById(Long userId) {
        Optional<UserEntity> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent())
            return userOpt.get();
        else
            throw new RuntimeException("user not found.");
    }

    @Override
    public void saveUser(UserEntity user) {
        UserEntity userDetail = userRepository.save(user);
        System.out.println("user saved to db with userId : " + userDetail.getId());
    }

    @Override
    public void updateUser(UserEntity user, Long userId) {
        Optional<UserEntity> userDetailOpt = userRepository.findById(userId);
        if (userDetailOpt.isPresent()) {
            UserEntity userDetail = userDetailOpt.get();
            if (user.getfirst() != null || user.getfirst().isEmpty())
                userDetail.setfirst(user.getfirst());
            if (user.getlast() != null || user.getlast().isEmpty())
                userDetail.setlast(user.getlast());
            userRepository.save(userDetail);
        } else {
            throw new RuntimeException("user not found.");
        }
    }

    @Override
    public void deleteUseryId(Long userId) {
        Optional<UserEntity> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent())
            userRepository.deleteById(userId);
        else
            throw new RuntimeException("user not found.");
    }
}
